<?php 
//Include Twitter config file && User class
include_once 'twConfig.php';
include_once 'User.php';

?>
   
<?php

//If OAuth token not matched
if(isset($_REQUEST['oauth_token']) && $_SESSION['token'] !== $_REQUEST['oauth_token']){
    //Remove token from session
    unset($_SESSION['token']);
    unset($_SESSION['token_secret']);
}

//If user already verified 
if(isset($_SESSION['status']) && $_SESSION['status'] == 'verified' && !empty($_SESSION['request_vars'])){
    //Retrive variables from session
    $username         = $_SESSION['request_vars']['screen_name'];
    $twitterId        = $_SESSION['request_vars']['user_id'];
    $oauthToken       = $_SESSION['request_vars']['oauth_token'];
    $oauthTokenSecret = $_SESSION['request_vars']['oauth_token_secret'];
    $profilePicture   = $_SESSION['userData']['picture'];
    
    /*
     * Prepare output to show to the user
     */
    $twClient = new TwitterOAuth($consumerKey, $consumerSecret, $oauthToken, $oauthTokenSecret);
    
    //If user submits a tweet to post to twitter
    if(isset($_POST["updateme"])){
        $my_update = $twClient->post('statuses/update', array('status' => $_POST["updateme"]));
    }
    
    
    //Get latest tweets
    $myTweets = $twClient->get('statuses/user_timeline', array('screen_name' => $username, 'count' => 5));
    
   if(isset($_POST["ExportType"]))
	{
		$twitt = "";
		$i=1;
		$twitt .= "<table>
				<tr><td>S. No</td>
					<td>Twitt</td>
					<td>Date</td></tr>";
		foreach($myTweets  as $tweet){
			
		  $twitt .=  "<tr><td>".$i++."</td><td>".$tweet->text."/td>";
		  $twitt .=   "<td>".$tweet->created_at."/td></tr>";
		}
		$twitt .="</table>";
		header("Content-Type: application/xls");    
		header("Content-Disposition: attachment; filename=excel.xls");  
		header("Pragma: no-cache"); 
		header("Expires: 0");
		print $twitt;
	}
	
}
   
?>