<?php
if(!session_id()){
    session_start();
}

//Include Twitter client library 
include_once 'twitteroauth/twitteroauth.php';

/*
 * Configuration and setup Twitter API
 */
$consumerKey    = '61b5pjGCIE0G6NPlafXBLXSTJ';
$consumerSecret = 'llVrlGbI3jpwOuGJrth1SZU75QSV7v1wp6DmdpQVk0hPxBR5Xg';
$redirectURL    = 'http://localhost/twitter_login/';

?>