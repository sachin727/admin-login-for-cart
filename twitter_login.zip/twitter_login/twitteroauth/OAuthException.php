<?php
class OAuthException extends Exception {
	// pass
}