-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2017 at 02:05 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ci_sample`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(100) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `user_agent` varchar(100) NOT NULL,
  `last_activity` varchar(100) NOT NULL,
  `user_data` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
(2, 8, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '1495786758', 'a:4:{s:20:"manufacture_selected";N;s:22:"search_string_selected";N;s:5:"order";N;s:10:"order_type";N');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `address`, `phone`, `date`) VALUES
(1, 'sachin', 'test@test.com', 'test', '4444444444', '2017-05-26 11:24:58'),
(2, 'sachin', 'test@test.com', 'test', '4444444444', '2017-05-26 11:25:41'),
(3, 'sachin', 'test@test.com', 'test', '4444444444', '2017-05-26 11:26:45'),
(4, 'ritesh', 'ritesh@test.com', 'indore', '1123456789', '2017-05-26 11:52:09'),
(5, 'rashmi', 'rashmi@infocratsweb.com', 'indore', '4444444444', '2017-05-29 10:23:54'),
(6, 'rajatjain', 'rajat@test.com', 'indore', '0000000000', '2017-06-08 10:02:57');

-- --------------------------------------------------------

--
-- Table structure for table `keys`
--

CREATE TABLE IF NOT EXISTS `keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`id`, `name`) VALUES
(1, 'sakura'),
(2, 'cello'),
(3, 'Electronic');

-- --------------------------------------------------------

--
-- Table structure for table `manufature_2`
--

CREATE TABLE IF NOT EXISTS `manufature_2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacture` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `manufature_2`
--

INSERT INTO `manufature_2` (`id`, `manufacture`, `name`, `date`) VALUES
(1, 3, 'monitor', '0000-00-00'),
(2, 2, 'pencil', '0000-00-00'),
(4, 1, 'glue', '0000-00-00'),
(5, 1, 'matelic', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE IF NOT EXISTS `membership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `pass_word` varchar(100) NOT NULL,
  `email_addres` varchar(100) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `membership`
--

INSERT INTO `membership` (`id`, `first_name`, `last_name`, `user_name`, `pass_word`, `email_addres`, `date`) VALUES
(1, 'sachn', 'tambe', 'sachin', 'e10adc3949ba59abbe56e057f20f883e', 'sachin@test.com', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` int(100) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customerid`, `date`) VALUES
(1, 2, '2017-05-26'),
(2, 3, '2017-05-26'),
(3, 4, '2017-05-26'),
(4, 5, '2017-05-29'),
(5, 6, '2017-06-08');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE IF NOT EXISTS `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(100) NOT NULL,
  `productid` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `orderid`, `productid`, `quantity`, `price`, `date`) VALUES
(1, 2, 0, 1, 40, '2017-05-26 11:26:45'),
(2, 2, 0, 1, 10, '2017-05-26 11:26:45'),
(3, 2, 0, 1, 30, '2017-05-26 11:26:46'),
(4, 2, 1, 1, 150, '2017-05-26 11:26:46'),
(5, 3, 1, 2, 150, '2017-05-26 11:52:10'),
(6, 3, 3, 1, 45000, '2017-05-26 11:52:10'),
(7, 4, 1, 4, 150, '2017-05-29 10:23:54'),
(8, 4, 34, 3, 200, '2017-05-29 10:23:54'),
(9, 5, 34, 3, 200, '2017-06-08 10:02:57'),
(10, 5, 1, 6, 150, '2017-06-08 10:02:57'),
(11, 5, 3, 3, 45000, '2017-06-08 10:02:57');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL,
  `payment_id` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `total` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `zip` varchar(10) NOT NULL,
  `city` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacture_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `stock` varchar(255) NOT NULL,
  `cost_price` int(255) NOT NULL,
  `image` varchar(200) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `sell_price` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `manufacture_id`, `name`, `description`, `stock`, `cost_price`, `image`, `original_name`, `sell_price`) VALUES
(1, 2, 'pens', 'pens', '100', 150, '38d494f42bca4d4af7efa8314d299f2a.jpg', 'Desert.jpg', 200),
(3, 2, 'Mobile', 'Mobile', '2', 45000, 'a074c58fdc901d3a1e42186aed0620b6.jpg', 'third.jpg', 46000),
(34, 1, 'Laptop', 'Laptop', '2', 2200, 'e7d1475146df595f0e53760706d2de1f.jpg', 'Lighthouse.jpg', 44340),
(35, 3, 'watch', 'new watches', '10', 599, '6e87cc442539ed545d6206f122e5e1b8.jpg', 'second.jpg', 650);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
