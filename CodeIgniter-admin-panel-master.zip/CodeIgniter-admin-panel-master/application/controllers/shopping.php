<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Shopping extends CI_Controller {

public function __construct()
{
parent::__construct();
//Load Library and model.
$this->load->library('cart');
$this->load->model('billing_model');
}

public function index()
{
//Get all data from database
$data['products'] = $this->billing_model->get_all();
//send all product data to "shopping_view", which fetch from database.
$this->load->view('shopping_view', $data);
}

function add()
{
// Set array for send data.
$insert_data = array(
'id' => $this->input->post('id'),
'name' => $this->input->post('name'),
'price' => $this->input->post('price'),
'qty' => 1
); 

// This function add items into cart.
$this->cart->insert($insert_data);

// This will show insert data in cart.
redirect('shopping');
}

function buynow($rowid) {
// Check rowid value.
if ($rowid==="buynow"){
// Destroy data which store in session.
// Recieve post values,calcute them and update
$cart_info = $_POST['cart'] ;
foreach( $cart_info as $id => $cart)
{
$rowid = $cart['rowid'];
$price = $cart['price'];
$amount = $price * $cart['qty'];
$qty = $cart['qty'];

$data = array(
'rowid' => $rowid,
'price' => $price,
'amount' => $amount,
'qty' => $qty
);

$this->cart->update($data);
}
}
// This will show cancel data in cart.
redirect('shopping');
}

function remove($rowid) {
// Check rowid value.
if ($rowid==="all"){
// Destroy data which store in session.
$this->cart->destroy();
}else{
// Destroy selected rowid in session.
$data = array(
'rowid' => $rowid,
'qty' => 0
);
// Update cart data, after cancel.
$this->cart->update($data);
}

// This will show cancel data in cart.
redirect('shopping');
}

function update_cart(){

// Recieve post values,calcute them and update
$cart_info = $_POST['cart'] ;
foreach( $cart_info as $id => $cart)
{
$rowid = $cart['rowid'];
$price = $cart['price'];
$amount = $price * $cart['qty'];
$qty = $cart['qty'];

$data = array(
'rowid' => $rowid,
'price' => $price,
'amount' => $amount,
'qty' => $qty
);

$this->cart->update($data);
}
redirect('shopping');
}

function billing_view(){
// Load "billing_view".
$this->load->view('billing_view');
}

function buy_now()
{
	//load buy now
	$this->load->view('buy_now');
}


function charge()
{ 
  require 'stripe/Stripe.php';
 
 $params = array(
	"testmode"   => "on",
	"private_live_key" => "sk_live_xxxxxxxxxxxxxxxxxxxxx",
	"public_live_key"  => "pk_live_xxxxxxxxxxxxxxxxxxxxx",
	"private_test_key" => "sk_test_ZEraZsCW3XqXoJ6Y878DYxmX",
	"public_test_key"  => "pk_test_oZDxs9bvUnTKPaTElyXOiI98"
);
	

if ($params['testmode'] == "on") {
	Stripe::setApiKey($params['private_test_key']);
	  $pubkey = $params['public_test_key'];  
} else {
	Stripe::setApiKey($params['private_live_key']);
	$pubkey = $params['public_live_key'];
}
		 
 	 if(isset($_POST['stripeToken']))
	 {
	$amount_cents = str_replace(".","",$_POST['amount']);  // Chargeble amount
	$invoiceid = "14526321";                      // Invoice ID
	$description = "Invoice #" . $invoiceid . " - " . $invoiceid;
	
	try {

		$charge = Stripe_Charge::create(array(		 
			  "amount" => $amount_cents,
			  "currency" => "usd",
			  "source" => $_POST['stripeToken'],
			  "description" => $description)			  
		);
	 
		if (@$charge->card->address_zip_check == "fail") {
			throw new Exception("zip_check_invalid");
		} else if (@$charge->card->address_line1_check == "fail") {
			throw new Exception("address_check_invalid");
		} else if (@$charge->card->cvc_check == "fail") {
			throw new Exception("cvc_check_invalid");
		}
		// Payment has succeeded, no exceptions were thrown or otherwise caught				

		$result = "success";

	} catch(Stripe_CardError $e) {			

		$error = $e->getMessage();
		$result = "declined";

	} catch (Stripe_InvalidRequestError $e) {
		$result = "declined";		  
	} catch (Stripe_AuthenticationError $e) {
		$result = "declined";
	} catch (Stripe_ApiConnectionError $e) {
		$result = "declined";
	} catch (Stripe_Error $e) {
		$result = "declined";
	} catch (Exception $e) {

		if ($e->getMessage() == "zip_check_invalid") {
			$result = "declined";
		} else if ($e->getMessage() == "address_check_invalid") {
			$result = "declined";
		} else if ($e->getMessage() == "cvc_check_invalid") {
			$result = "declined";
		} else {
			$result = "declined";
		}		  
	}
	
	echo "<BR>Stripe Payment Status : ".$result;
	
	echo "<BR>Stripe Response : ";
	
	echo "<pre>";print_r($charge);echo "</pre>"; exit;
 }
}
 
public function save_order()
{
// This will store all values which inserted from user.
$customer = array(
'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'address' => $this->input->post('address'),
'phone' => $this->input->post('phone')
);
// And store user information in database.
$cust_id = $this->billing_model->insert_customer($customer);

$order = array(
'date' => date('Y-m-d'),
'customerid' => $cust_id
);

$ord_id = $this->billing_model->insert_order($order);

if ($cart = $this->cart->contents()):
foreach ($cart as $item):
$order_detail = array(
'orderid' => $ord_id,
'productid' => $item['id'],
'quantity' => $item['qty'],
'price' => $item['price']
);

// Insert product imformation with order detail, store in cart also store in database.

$cust_id = $this->billing_model->insert_order_detail($order_detail);
endforeach;
endif;

// After storing all imformation in database load "billing_success".
$this->load->view('billing_success');
}
}
?>

