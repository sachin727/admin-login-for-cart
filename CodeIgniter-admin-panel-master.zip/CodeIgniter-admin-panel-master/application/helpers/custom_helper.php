<?php if(!defined('BASEPATH')) exit('no direct script access allowed');
	   
if ( ! function_exists('category')){
function category()
{
	$CI=&get_instance(); 
	$CI->db->from("manufacturers");
	$query = $CI->db->get(); 
	$query->row_array();  
	return $query;
}
}

if ( ! function_exists('category_id')){
function category_id($id)
{
	$CI=&get_instance(); 
	$CI->db->from("manufacturers");
	$CI->db->where("id",$id);
	$query = $CI->db->get(); 
	$query->row_array();  
	return $query;
}
}
