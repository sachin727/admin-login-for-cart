# ci-stripe-library
A CodeIgniter library for working with the The Stripe API 
