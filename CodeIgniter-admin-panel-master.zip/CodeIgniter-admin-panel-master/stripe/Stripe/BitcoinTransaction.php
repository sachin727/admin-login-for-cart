<?php

class Stripe_BitcoinTransaction extends Stripe_ApiResource
{

}

